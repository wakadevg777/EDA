				
				----------Delivarables ---------------------


1. DataSet: https://github.com/wakadevg777/mydataset/blob/master/BanksInterestRatesAnalys.xlsx?raw=true', sheet_name=0
One copy is provided along (BanksInterestRatesAnalys.xlsx)

2.EDA Notebook --EDA_pythonNotebook.ipynb

3.Dataset before Profiling -InterestRates_data_after_Profiling.html

4.Dataset after Profiling -InterestRates_data_before_Profiling.html

5.A EDA PPT presentation - Banks Interest Rates EDA PPT Presentation.mp4

6.A EDA PPT: BanksInterest RatesEDA_PPTPresentation.pptx

